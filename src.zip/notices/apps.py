from django.apps import AppConfig


class NoticesConfig(AppConfig):
    name = 'notices'
