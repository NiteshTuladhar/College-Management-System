from django.apps import AppConfig


class AssignmentsConfig(AppConfig):
    name = 'assignments'
