from django.apps import AppConfig


class InternalmarkspredictionConfig(AppConfig):
    name = 'InternalMarksPrediction'
