from django.apps import AppConfig


class CollegecalendarConfig(AppConfig):
    name = 'collegecalendar'
