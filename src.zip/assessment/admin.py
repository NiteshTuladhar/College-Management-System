from django.contrib import admin
from .models import AssessmentTopView, Assesment

# Register your models here.
admin.site.register(AssessmentTopView)
admin.site.register(Assesment)