from django.apps import AppConfig


class AssessmentConfig(AppConfig):
    name = 'assessment'
